﻿using System;

public class BEConexion
{
    public static string strCadenaConexion = "Data Source=TEOFILO\\SQLEXPRESS;Initial Catalog=SISCONTROLPRESUPUESTAL;Integrated Security=True";

    public static string vg_strCadenaConexion
    {
        get { return strCadenaConexion; } 
    }
}
