﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public class Grilla
    {
        public static void EsconderColumnas(DataGridView dg, List<int> listaColumnas)
        {
            //foreach (int numeroColumna in listaColumnas)
            //{
            //    dg.Columns[numeroColumna].Visible = false;
            //}
        }

        public static void PonerCabeceraAGrid(DataGridView dg, string[] listaCabecera)
        {
            for (int i = 0; i < dg.Columns.Count; i++)
            {
                dg.Columns[i].HeaderText = listaCabecera[i];
            }
        }
    }
}
