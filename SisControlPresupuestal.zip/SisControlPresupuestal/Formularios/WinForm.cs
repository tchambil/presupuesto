﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public class WinForm
    {
        public static void LimpiarTextBox(Form formulario)
        {
            foreach (Control w in formulario.Controls)
            {
                if (w is TextBox)
                {
                    TextBox txt = (TextBox)w;
                    txt.Text = "";
                }
                if (w is RichTextBox)
                {
                    RichTextBox rtb = (RichTextBox)w;
                    rtb.Text = "";
                }
                if (w is ComboBox)
                {
                    ComboBox cb = (ComboBox)w;
                    cb.Text = "";
                }
                if (w is DateTimePicker)
                {
                    DateTimePicker dtp = (DateTimePicker)w;
                    dtp.Text = "";
                }


            }
        }
        public static void DesbloquearTextBox(Form formulario)
        {
            foreach (Control w in formulario.Controls)
            {
                if (w is TextBox)
                {
                    TextBox txt = (TextBox)w;
                    txt.Enabled = true;
                }
                if (w is RichTextBox)
                {
                    RichTextBox rtb = (RichTextBox)w;
                    rtb.Enabled = true;
                }
                if (w is ComboBox)
                {
                    ComboBox cb = (ComboBox)w;
                    cb.Enabled = true;
                }
                if (w is DateTimePicker)
                {
                    DateTimePicker dtp = (DateTimePicker)w;
                    dtp.Enabled = true;
                }


            }
        }

        public static void BloquearTextBox(Form formulario)
        {
            foreach (Control w in formulario.Controls)
            {
                if (w is TextBox)
                {
                    TextBox txt = (TextBox)w;
                    txt.Enabled = false;
                }
                if (w is RichTextBox)
                {
                    RichTextBox rtb = (RichTextBox)w;
                    rtb.Enabled = false;
                }

                if (w is ComboBox)
                {
                    ComboBox cb = (ComboBox)w;
                    cb.Enabled = false;
                }
                if (w is DateTimePicker)
                {
                    DateTimePicker dtp = (DateTimePicker)w;
                    dtp.Enabled = false;
                }

            }
        }

        
        
        

    }
}
