﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public class Botones
    {
        public static void EstablecerEstadoBotones(List<Button> botones,bool EsDefault)
        {
            if(EsDefault == true)
            {
                botones[0].Enabled = true;
                botones[1].Enabled = false;
                botones[2].Enabled = true;
                botones[3].Enabled = false;
            
            }
            else
            {
                botones[0].Enabled = false;
                botones[1].Enabled = true;
                botones[2].Enabled = false;
                botones[3].Enabled = true;
           
            }
        }
       
    }
}
