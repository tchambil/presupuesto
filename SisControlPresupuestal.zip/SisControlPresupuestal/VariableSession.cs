﻿using System;

public class VariableSession
{
    public static string _cadenaconexion = "Data Source=localhost;Initial Catalog=SISCONTROLPRESUPUESTAL;Integrated Security=True";

    public static string cadenaconexion
    {
        get { return _cadenaconexion; } 
    }
}
