﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class Backup_DAL
    {
        public bool BackupGenerate(String path, SqlConnection sqlConection)
        {
            bool b_MetaEspecifica;

            try
            {
                String SQL = string.Format(@"BACKUP DATABASE SISCONTROLPRESUPUESTAL TO DISK = '"+ path +"'");
                SqlCommand cmdComand = new SqlCommand(SQL, sqlConection);
                sqlConection.Open();
                b_MetaEspecifica = cmdComand.ExecuteNonQuery() > 0;
                sqlConection.Close();
            }
            catch (Exception e)
            {
                if (e.Source != null)
                    Console.WriteLine("IOException source: {0}", e.Source);
                throw;
            }
            return b_MetaEspecifica;
        }
    }
}
