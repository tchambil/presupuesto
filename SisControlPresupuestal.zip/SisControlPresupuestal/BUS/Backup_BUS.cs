﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using VO;
using System.Data.SqlClient;

namespace BUS
{
    public class Backup_BUS
    {
        public bool BackupGenerate(string path)
        {
            SqlConnection sqlConection = null; 
            bool b_Backup = false;

            try
            {
                sqlConection = new SqlConnection(BEConexion.vg_strCadenaConexion);
                      
                b_Backup = new Backup_DAL().BackupGenerate(path, sqlConection);
                
            }

            catch (Exception exception)
            {
                throw exception;  
            }
            
            
            return b_Backup;
        }
    }
}
