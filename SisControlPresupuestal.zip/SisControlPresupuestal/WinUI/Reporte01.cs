﻿using BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Reporte01 : Form
    {
        List<string> conexion = new CONEXION_BUS().LeerConexion();
        public Reporte01()
        {
            InitializeComponent();
        }

        private void Reporte01_Load(object sender, EventArgs e)
        {
            string cadenaConexion = string.Empty;

            if (conexion.Count > 3)
            {
                cadenaConexion = @"Data Source=" + conexion[0] + ";Initial Catalog=" + conexion[1] + ";user=" + conexion[2] + ";password=" + conexion[3];
                // TODO: esta línea de código carga datos en la tabla 'SisDocDataSet.SPR_VerReporte01' Puede moverla o quitarla según sea necesario.
            }
            else
            {
                cadenaConexion = @"Data Source=" + conexion[0] + ";Initial Catalog=" + conexion[1] +";Integrated Security="+conexion[2];
            }
            this.SPR_VerReporte01TableAdapter.Connection.ConnectionString = cadenaConexion;
            this.SPR_VerReporte01TableAdapter.Fill(this.SisDocDataSet.SPR_VerReporte01);

            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }
    }
}
