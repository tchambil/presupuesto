﻿namespace WinUI
{
    partial class frmReporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbEspecifica = new System.Windows.Forms.ComboBox();
            this.cmbMetas = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAnio = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbEspecifica);
            this.groupBox1.Controls.Add(this.cmbMetas);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtAnio);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(710, 52);
            this.groupBox1.TabIndex = 101;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "General";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(380, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 102;
            this.label2.Text = "Especifica Gasto";
            // 
            // cmbEspecifica
            // 
            this.cmbEspecifica.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEspecifica.FormattingEnabled = true;
            this.cmbEspecifica.Location = new System.Drawing.Point(473, 17);
            this.cmbEspecifica.Name = "cmbEspecifica";
            this.cmbEspecifica.Size = new System.Drawing.Size(90, 21);
            this.cmbEspecifica.TabIndex = 101;
            // 
            // cmbMetas
            // 
            this.cmbMetas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMetas.FormattingEnabled = true;
            this.cmbMetas.Location = new System.Drawing.Point(279, 17);
            this.cmbMetas.Name = "cmbMetas";
            this.cmbMetas.Size = new System.Drawing.Size(90, 21);
            this.cmbMetas.TabIndex = 91;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(219, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 13);
            this.label13.TabIndex = 92;
            this.label13.Text = "Metas";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 98;
            this.label6.Text = "Año ";
            // 
            // txtAnio
            // 
            this.txtAnio.Location = new System.Drawing.Point(103, 15);
            this.txtAnio.Name = "txtAnio";
            this.txtAnio.Size = new System.Drawing.Size(90, 20);
            this.txtAnio.TabIndex = 97;
            // 
            // frmReporte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 564);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmReporte";
            this.Text = "frmReporte";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbEspecifica;
        private System.Windows.Forms.ComboBox cmbMetas;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAnio;
    }
}