﻿namespace WinUI
{
    partial class DetalleControlPresupuestalUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbMetas = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAnio = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvGastoEspecifico = new System.Windows.Forms.DataGridView();
            this.colAnio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIdMeta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEspecificaGasto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPIM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colModifiacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPresupuesto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEnero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFebrero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMarzo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAbril = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMayo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJunio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJulio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAgosto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSetiembre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOctubre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoviembre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiciembre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEjecutado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSaldo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbEspecifica = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpim = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPIModificado = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnGuardarModifica = new System.Windows.Forms.Button();
            this.btnNuevoModifica = new System.Windows.Forms.Button();
            this.dgvModificado = new System.Windows.Forms.DataGridView();
            this.colIdModificado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colidMetaModificado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIdEspecificaModificado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImporteModificado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGastoEspecifico)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModificado)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(746, 66);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 74;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(584, 66);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 73;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(503, 66);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 71;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(422, 66);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnNuevo.TabIndex = 72;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(219, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 13);
            this.label13.TabIndex = 92;
            this.label13.Text = "Metas";
            // 
            // cmbMetas
            // 
            this.cmbMetas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMetas.FormattingEnabled = true;
            this.cmbMetas.Location = new System.Drawing.Point(279, 17);
            this.cmbMetas.Name = "cmbMetas";
            this.cmbMetas.Size = new System.Drawing.Size(90, 21);
            this.cmbMetas.TabIndex = 91;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(363, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(297, 13);
            this.label5.TabIndex = 93;
            this.label5.Text = "FORMULARIO - DETALLE DE CONTROL PRESUPUESTAL";
            // 
            // txtAnio
            // 
            this.txtAnio.Location = new System.Drawing.Point(103, 15);
            this.txtAnio.Name = "txtAnio";
            this.txtAnio.Size = new System.Drawing.Size(90, 20);
            this.txtAnio.TabIndex = 97;
            this.txtAnio.TextChanged += new System.EventHandler(this.txtAnio_TextChanged);
            this.txtAnio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAnio_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 98;
            this.label6.Text = "Año ";
            // 
            // dgvGastoEspecifico
            // 
            this.dgvGastoEspecifico.AllowUserToAddRows = false;
            this.dgvGastoEspecifico.AllowUserToDeleteRows = false;
            this.dgvGastoEspecifico.AllowUserToResizeColumns = false;
            this.dgvGastoEspecifico.AllowUserToResizeRows = false;
            this.dgvGastoEspecifico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGastoEspecifico.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colAnio,
            this.colIdMeta,
            this.colEspecificaGasto,
            this.colPIM,
            this.colModifiacion,
            this.colPresupuesto,
            this.colEnero,
            this.colFebrero,
            this.colMarzo,
            this.colAbril,
            this.colMayo,
            this.colJunio,
            this.colJulio,
            this.colAgosto,
            this.colSetiembre,
            this.colOctubre,
            this.colNoviembre,
            this.colDiciembre,
            this.colEjecutado,
            this.colSaldo});
            this.dgvGastoEspecifico.Location = new System.Drawing.Point(6, 6);
            this.dgvGastoEspecifico.Name = "dgvGastoEspecifico";
            this.dgvGastoEspecifico.ReadOnly = true;
            this.dgvGastoEspecifico.RowHeadersVisible = false;
            this.dgvGastoEspecifico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGastoEspecifico.Size = new System.Drawing.Size(1238, 443);
            this.dgvGastoEspecifico.TabIndex = 99;
            this.dgvGastoEspecifico.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGastoEspecifico_CellClick);
            this.dgvGastoEspecifico.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGastoEspecifico_CellClick);
            this.dgvGastoEspecifico.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvGastoEspecifico_CellFormatting);
            // 
            // colAnio
            // 
            this.colAnio.DataPropertyName = "MEGA_VCH_ANIO";
            this.colAnio.HeaderText = "Anio";
            this.colAnio.Name = "colAnio";
            this.colAnio.ReadOnly = true;
            this.colAnio.Visible = false;
            // 
            // colIdMeta
            // 
            this.colIdMeta.DataPropertyName = "META_VCH_IDMETA";
            this.colIdMeta.HeaderText = "Meta";
            this.colIdMeta.Name = "colIdMeta";
            this.colIdMeta.ReadOnly = true;
            this.colIdMeta.Visible = false;
            // 
            // colEspecificaGasto
            // 
            this.colEspecificaGasto.DataPropertyName = "EGAS_VCH_IDESPECIFICADEGASTO";
            this.colEspecificaGasto.HeaderText = "EspecificaGasto";
            this.colEspecificaGasto.Name = "colEspecificaGasto";
            this.colEspecificaGasto.ReadOnly = true;
            this.colEspecificaGasto.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colEspecificaGasto.Width = 87;
            // 
            // colPIM
            // 
            this.colPIM.DataPropertyName = "MEGA_DEC_PIM";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N2";
            dataGridViewCellStyle1.NullValue = null;
            this.colPIM.DefaultCellStyle = dataGridViewCellStyle1;
            this.colPIM.HeaderText = "PIM";
            this.colPIM.Name = "colPIM";
            this.colPIM.ReadOnly = true;
            this.colPIM.Width = 70;
            // 
            // colModifiacion
            // 
            this.colModifiacion.DataPropertyName = "MEGA_MODIFICACION";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.colModifiacion.DefaultCellStyle = dataGridViewCellStyle2;
            this.colModifiacion.HeaderText = "Modificacion";
            this.colModifiacion.Name = "colModifiacion";
            this.colModifiacion.ReadOnly = true;
            this.colModifiacion.Width = 70;
            // 
            // colPresupuesto
            // 
            this.colPresupuesto.DataPropertyName = "MEGA_PRESUPUESTO";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            this.colPresupuesto.DefaultCellStyle = dataGridViewCellStyle3;
            this.colPresupuesto.HeaderText = "Presupuesto";
            this.colPresupuesto.Name = "colPresupuesto";
            this.colPresupuesto.ReadOnly = true;
            this.colPresupuesto.Width = 70;
            // 
            // colEnero
            // 
            this.colEnero.DataPropertyName = "ENERO";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            this.colEnero.DefaultCellStyle = dataGridViewCellStyle4;
            this.colEnero.HeaderText = "Enero";
            this.colEnero.Name = "colEnero";
            this.colEnero.ReadOnly = true;
            this.colEnero.Width = 65;
            // 
            // colFebrero
            // 
            this.colFebrero.DataPropertyName = "FEBRERO";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N2";
            this.colFebrero.DefaultCellStyle = dataGridViewCellStyle5;
            this.colFebrero.HeaderText = "Febrero";
            this.colFebrero.Name = "colFebrero";
            this.colFebrero.ReadOnly = true;
            this.colFebrero.Width = 65;
            // 
            // colMarzo
            // 
            this.colMarzo.DataPropertyName = "MARZO";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            this.colMarzo.DefaultCellStyle = dataGridViewCellStyle6;
            this.colMarzo.HeaderText = "Marzo";
            this.colMarzo.Name = "colMarzo";
            this.colMarzo.ReadOnly = true;
            this.colMarzo.Width = 65;
            // 
            // colAbril
            // 
            this.colAbril.DataPropertyName = "ABRIL";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            this.colAbril.DefaultCellStyle = dataGridViewCellStyle7;
            this.colAbril.HeaderText = "Abril";
            this.colAbril.Name = "colAbril";
            this.colAbril.ReadOnly = true;
            this.colAbril.Width = 65;
            // 
            // colMayo
            // 
            this.colMayo.DataPropertyName = "MAYO";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N2";
            this.colMayo.DefaultCellStyle = dataGridViewCellStyle8;
            this.colMayo.HeaderText = "Mayo";
            this.colMayo.Name = "colMayo";
            this.colMayo.ReadOnly = true;
            this.colMayo.Width = 65;
            // 
            // colJunio
            // 
            this.colJunio.DataPropertyName = "JUNIO";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N2";
            this.colJunio.DefaultCellStyle = dataGridViewCellStyle9;
            this.colJunio.HeaderText = "Junio";
            this.colJunio.Name = "colJunio";
            this.colJunio.ReadOnly = true;
            this.colJunio.Width = 65;
            // 
            // colJulio
            // 
            this.colJulio.DataPropertyName = "JULIO";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            this.colJulio.DefaultCellStyle = dataGridViewCellStyle10;
            this.colJulio.HeaderText = "Julio";
            this.colJulio.Name = "colJulio";
            this.colJulio.ReadOnly = true;
            this.colJulio.Width = 65;
            // 
            // colAgosto
            // 
            this.colAgosto.DataPropertyName = "AGOSTO";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "N2";
            this.colAgosto.DefaultCellStyle = dataGridViewCellStyle11;
            this.colAgosto.HeaderText = "Agosto";
            this.colAgosto.Name = "colAgosto";
            this.colAgosto.ReadOnly = true;
            this.colAgosto.Width = 65;
            // 
            // colSetiembre
            // 
            this.colSetiembre.DataPropertyName = "SEPTIEMBRE";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "N2";
            this.colSetiembre.DefaultCellStyle = dataGridViewCellStyle12;
            this.colSetiembre.HeaderText = "Setiembre";
            this.colSetiembre.Name = "colSetiembre";
            this.colSetiembre.ReadOnly = true;
            this.colSetiembre.Width = 65;
            // 
            // colOctubre
            // 
            this.colOctubre.DataPropertyName = "OCTUBRE";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle13.Format = "N2";
            this.colOctubre.DefaultCellStyle = dataGridViewCellStyle13;
            this.colOctubre.HeaderText = "Octubre";
            this.colOctubre.Name = "colOctubre";
            this.colOctubre.ReadOnly = true;
            this.colOctubre.Width = 65;
            // 
            // colNoviembre
            // 
            this.colNoviembre.DataPropertyName = "NOVIEMBRE";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "N2";
            this.colNoviembre.DefaultCellStyle = dataGridViewCellStyle14;
            this.colNoviembre.HeaderText = "Noviembre";
            this.colNoviembre.Name = "colNoviembre";
            this.colNoviembre.ReadOnly = true;
            this.colNoviembre.Width = 65;
            // 
            // colDiciembre
            // 
            this.colDiciembre.DataPropertyName = "DICIEMBRE";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "N2";
            this.colDiciembre.DefaultCellStyle = dataGridViewCellStyle15;
            this.colDiciembre.HeaderText = "Diciembre";
            this.colDiciembre.Name = "colDiciembre";
            this.colDiciembre.ReadOnly = true;
            this.colDiciembre.Width = 65;
            // 
            // colEjecutado
            // 
            this.colEjecutado.DataPropertyName = "TOTALEJECUTADO";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "N2";
            this.colEjecutado.DefaultCellStyle = dataGridViewCellStyle16;
            this.colEjecutado.HeaderText = "Ejecutado";
            this.colEjecutado.Name = "colEjecutado";
            this.colEjecutado.ReadOnly = true;
            this.colEjecutado.Width = 70;
            // 
            // colSaldo
            // 
            this.colSaldo.DataPropertyName = "SADOEJERCICIO";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle17.Format = "N2";
            this.colSaldo.DefaultCellStyle = dataGridViewCellStyle17;
            this.colSaldo.HeaderText = "Saldo";
            this.colSaldo.Name = "colSaldo";
            this.colSaldo.ReadOnly = true;
            this.colSaldo.Width = 70;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbEspecifica);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtpim);
            this.groupBox1.Controls.Add(this.cmbMetas);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtAnio);
            this.groupBox1.Location = new System.Drawing.Point(2, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 71);
            this.groupBox1.TabIndex = 100;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "General";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 102;
            this.label2.Text = "Especifica Gasto";
            // 
            // cmbEspecifica
            // 
            this.cmbEspecifica.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEspecifica.FormattingEnabled = true;
            this.cmbEspecifica.Location = new System.Drawing.Point(103, 44);
            this.cmbEspecifica.Name = "cmbEspecifica";
            this.cmbEspecifica.Size = new System.Drawing.Size(90, 21);
            this.cmbEspecifica.TabIndex = 101;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(209, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 100;
            this.label1.Text = "Importe PIM";
            // 
            // txtpim
            // 
            this.txtpim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpim.Location = new System.Drawing.Point(279, 46);
            this.txtpim.Name = "txtpim";
            this.txtpim.Size = new System.Drawing.Size(90, 20);
            this.txtpim.TabIndex = 99;
            this.txtpim.TextChanged += new System.EventHandler(this.txtpim_TextChanged);
            this.txtpim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpim_KeyPress);
            // 
            // txtTotal
            // 
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtTotal.Location = new System.Drawing.Point(1130, 455);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 101;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 99);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1273, 547);
            this.tabControl1.TabIndex = 102;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.dgvGastoEspecifico);
            this.tabPage1.Controls.Add(this.txtTotal);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1265, 521);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Especifica de Gasto";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1053, 462);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 102;
            this.label4.Text = "Total General";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnEliminar);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.btnGuardarModifica);
            this.tabPage2.Controls.Add(this.btnNuevoModifica);
            this.tabPage2.Controls.Add(this.dgvModificado);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1265, 521);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modificaciones";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtPIModificado);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(183, 50);
            this.groupBox2.TabIndex = 109;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Datos ";
            // 
            // txtPIModificado
            // 
            this.txtPIModificado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPIModificado.Location = new System.Drawing.Point(76, 19);
            this.txtPIModificado.Name = "txtPIModificado";
            this.txtPIModificado.Size = new System.Drawing.Size(90, 20);
            this.txtPIModificado.TabIndex = 101;
            this.txtPIModificado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPIModificado.TextChanged += new System.EventHandler(this.txtPIModificado_TextChanged);
            this.txtPIModificado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPIModificado_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 102;
            this.label3.Text = "Importe PIM";
            // 
            // btnGuardarModifica
            // 
            this.btnGuardarModifica.Enabled = false;
            this.btnGuardarModifica.Location = new System.Drawing.Point(206, 94);
            this.btnGuardarModifica.Name = "btnGuardarModifica";
            this.btnGuardarModifica.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarModifica.TabIndex = 104;
            this.btnGuardarModifica.Text = "Guardar";
            this.btnGuardarModifica.UseVisualStyleBackColor = true;
            this.btnGuardarModifica.Click += new System.EventHandler(this.btnGuardarModifica_Click);
            // 
            // btnNuevoModifica
            // 
            this.btnNuevoModifica.Location = new System.Drawing.Point(206, 65);
            this.btnNuevoModifica.Name = "btnNuevoModifica";
            this.btnNuevoModifica.Size = new System.Drawing.Size(75, 23);
            this.btnNuevoModifica.TabIndex = 103;
            this.btnNuevoModifica.Text = "Nuevo";
            this.btnNuevoModifica.UseVisualStyleBackColor = true;
            this.btnNuevoModifica.Click += new System.EventHandler(this.btnNuevoModifica_Click);
            // 
            // dgvModificado
            // 
            this.dgvModificado.AllowUserToAddRows = false;
            this.dgvModificado.AllowUserToDeleteRows = false;
            this.dgvModificado.AllowUserToResizeColumns = false;
            this.dgvModificado.AllowUserToResizeRows = false;
            this.dgvModificado.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvModificado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModificado.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colIdModificado,
            this.colidMetaModificado,
            this.colIdEspecificaModificado,
            this.colImporteModificado});
            this.dgvModificado.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvModificado.Location = new System.Drawing.Point(6, 62);
            this.dgvModificado.MultiSelect = false;
            this.dgvModificado.Name = "dgvModificado";
            this.dgvModificado.ReadOnly = true;
            this.dgvModificado.RowHeadersVisible = false;
            this.dgvModificado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvModificado.Size = new System.Drawing.Size(166, 342);
            this.dgvModificado.TabIndex = 0;
            this.dgvModificado.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvModificado_CellContentClick);
            this.dgvModificado.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvModificado_CellContentClick);
            this.dgvModificado.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvModificado_CellContentClick);
            this.dgvModificado.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvModificado_CellFormatting);
            // 
            // colIdModificado
            // 
            this.colIdModificado.DataPropertyName = "MEGM_INT_IDMODIFICACION";
            this.colIdModificado.HeaderText = "IdModificado";
            this.colIdModificado.Name = "colIdModificado";
            this.colIdModificado.ReadOnly = true;
            this.colIdModificado.Visible = false;
            // 
            // colidMetaModificado
            // 
            this.colidMetaModificado.DataPropertyName = "META_VCH_IDMETA";
            this.colidMetaModificado.HeaderText = "idMetaModificado";
            this.colidMetaModificado.Name = "colidMetaModificado";
            this.colidMetaModificado.ReadOnly = true;
            this.colidMetaModificado.Visible = false;
            // 
            // colIdEspecificaModificado
            // 
            this.colIdEspecificaModificado.DataPropertyName = "EGAS_VCH_IDESPECIFICADEGASTO";
            this.colIdEspecificaModificado.HeaderText = "IdEspecificaModificado";
            this.colIdEspecificaModificado.Name = "colIdEspecificaModificado";
            this.colIdEspecificaModificado.ReadOnly = true;
            this.colIdEspecificaModificado.Visible = false;
            // 
            // colImporteModificado
            // 
            this.colImporteModificado.DataPropertyName = "MEGM_DEC_PIMMODIFICADO";
            dataGridViewCellStyle18.Format = "N2";
            dataGridViewCellStyle18.NullValue = null;
            this.colImporteModificado.DefaultCellStyle = dataGridViewCellStyle18;
            this.colImporteModificado.HeaderText = "Importe";
            this.colImporteModificado.Name = "colImporteModificado";
            this.colImporteModificado.ReadOnly = true;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(665, 66);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 103;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Enabled = false;
            this.btnEliminar.Location = new System.Drawing.Point(206, 123);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 110;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // DetalleControlPresupuestalUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 735);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnNuevo);
            this.Name = "DetalleControlPresupuestalUI";
            this.Text = "Formulario-Detalle de Control Presupuestal";
            this.Load += new System.EventHandler(this.DetalleEjecucionDevengadosUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGastoEspecifico)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModificado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbMetas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAnio;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvGastoEspecifico;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbEspecifica;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpim;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPIModificado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGuardarModifica;
        private System.Windows.Forms.Button btnNuevoModifica;
        private System.Windows.Forms.DataGridView dgvModificado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIdModificado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colidMetaModificado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIdEspecificaModificado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImporteModificado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAnio;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIdMeta;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEspecificaGasto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPIM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colModifiacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPresupuesto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEnero;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFebrero;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMarzo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAbril;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMayo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJunio;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJulio;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAgosto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSetiembre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOctubre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoviembre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiciembre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEjecutado;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSaldo;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEliminar;
    }
}